<?php
    ob_start();
    define ('UPLOAD_DIR', './i/');
    ob_end_clean();
?>